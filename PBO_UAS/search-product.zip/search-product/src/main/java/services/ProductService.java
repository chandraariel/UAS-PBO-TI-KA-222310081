package services;

public interface ProductService {
    void searchProduct();
}
